# Misiones

1. Acabar con el plan de Lex Luthor
2. Crear la liga de la justicia
3. Buscar nuevos miembros para la liga
5. Investigar los trabajos del Joker
6. Tratar de investigar que trama el Flash Reverso
